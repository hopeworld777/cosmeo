# Kosmeo — Internal Dispute & Moderation Framework
**Version 1.0 · June 2026 · Confidential — Internal Use Only**

---

## Overview

Kosmeo operates a zero-fee, peer-to-peer, hand-to-hand exchange model with no escrow,
no payment processing, and no shipping infrastructure. This means the platform cannot
reverse transactions, freeze funds, or compel item returns. What it *can* do is:

- Surface trust signals (tier medals, review history) that make bad actors visible before damage is done.
- Log every conversation and listing, giving moderators a full audit trail.
- Deprioritise or remove flagged content from the public feed quickly.
- Apply progressive account consequences (warning → suspension → ban).

This document defines the processes that make those levers work consistently.

---

## 1. Report Lifecycle — "Report Listing / User" Workflow

### 1.1 How a report is filed

A user can file a report from two surfaces:

| Surface | How | What it pre-populates |
|---|---|---|
| **Chat header** (Flag icon) | Taps the flag icon in an active conversation | `conversation_id`, `reported_user_id`, `listing_id` |
| **Listing page** (future) | "Report this listing" option in the item overflow menu | `listing_id`, `reported_user_id` |

The report sheet asks the user to select one of six reasons:

1. Attempted scam or fraud
2. Fake or misrepresented listing
3. Pressuring to move off Kosmeo chat
4. Harassment or threatening messages
5. Counterfeit or illegal items
6. Something else

The user may optionally add free-text detail (max 500 characters).

### 1.2 What happens immediately on submission

```
User taps Submit
       │
       ▼
POST /api/reports                        ← creates reports row, status = "open"
       │
       ├─ Duplicate check: same reporter + same target open? → 409, silently shown
       │   as "already submitted" to the user.
       │
       ├─ DB trigger fires: if listing now has ≥ 3 open reports →
       │   listings.is_flagged = true  (listing hidden from Browse/Home feed)
       │
       └─ User sees confirmation: "Report Received — reviewed within 48 hours"
```

The reporter's identity is **never disclosed** to the reported party.

### 1.3 Moderation queue (internal admin view)

Reach via `GET /api/reports/admin?status=open`.

Each queued item shows:

- Reporter username (internal only)
- Reported user + their tier medal + warning count
- Linked listing (title, photos, price)
- Linked conversation preview
- Reason + free-text detail
- Timestamp

**SLA target:** All `open` reports reviewed within 48 hours of creation.

### 1.4 Resolution actions available to moderators

| Action key | What it does | When to use |
|---|---|---|
| `warn_user` | `users.warning_count + 1` | First offence, likely misunderstanding or minor violation |
| `remove_listing` | `listings.is_active = false`, `is_flagged = true` | Fake listing, counterfeit, prohibited item |
| `ban_user` | `users.is_banned = true` (all listings hidden, login blocked) | Confirmed scam, repeat offender (≥ 3 warnings), harassment |
| *(no action)* | Status → "dismissed" with note | Report found to be unfounded |

Moderator records a `resolution_note` explaining the decision (internal record only).

### 1.5 Notifying the reporter (manual for now)

Until in-app push notifications are built:
- For resolved/dismissed reports, moderator sends a brief email via `hello@kosmeo.ge`.
- Template: *"We reviewed your report filed on [date]. [Action taken / no violation found]. Thank you for keeping Kosmeo safe."*
- Do **not** describe the action taken against the reported user (privacy).

### 1.6 Appeals

Any user who believes their account was incorrectly actioned may email `hello@kosmeo.ge`
with the subject line **"Account Appeal — [username]"**. A second moderator (not the
original reviewer) handles appeals within 7 days.

---

## 2. Post-Meetup Hidden Defect Resolution Guide

### Context

Kosmeo cannot compel refunds or enforce returns. This process is designed to:
(a) give the buyer a fair path to remedy, and (b) give the seller an opportunity
to resolve before facing account consequences.

### 2.1 Step-by-step for the buyer (surfaced in-app)

These steps map directly to the `defect_step*` i18n keys displayed
in the "Discover a problem?" flow:

**Step 1 — Document immediately (0–2 hours after meetup)**
Take clear photos and a short video of the defect while the item is still in your hands.
Timestamp is critical — it establishes that damage was pre-existing, not caused by the buyer.

**Step 2 — Contact the seller in Kosmeo chat**
Open the original conversation thread. Send the photos and a clear written description.
Propose a specific resolution: partial refund (negotiated amount) or a return meetup
at the same public hub within 7 days.

**Step 3 — 48-hour response window**
Give the seller 48 hours to respond. Most sellers respond quickly to protect their rating.
If the seller agrees, arrange the follow-up meetup at the recommended hub for that city.

**Step 4 — No response after 48 hours → file a report**
Tap the Flag icon in the chat header, select "Fake or misrepresented listing," and paste
your photo evidence into the detail field. Note that the seller did not respond.

**Step 5 — Kosmeo moderator review (48-hour SLA)**
The moderator will:
- Review the chat log, listing photos, and the buyer's defect evidence.
- Contact the seller directly via their registered email.
- If the defect is confirmed to have been deliberately concealed: `warn_user` or
  `remove_listing` depending on severity.
- If the pattern is repeated (same seller, multiple hidden-defect reports): `ban_user`.

**Step 6 — Buyer leaves a review**
Regardless of outcome, the buyer should leave an accurate star rating and written review.
This is the primary protection for future community members.

### 2.2 What Kosmeo cannot do

Be transparent with users about these limits:

- **Cannot compel a refund.** Kosmeo has no access to funds; any refund is between the two parties.
- **Cannot guarantee a return meetup happens.** If the seller refuses to meet, the buyer's recourse is the review system and the moderation report.
- **Cannot mediate the value of a partial defect.** Suggest both parties agree on a fair deduction in chat.

These limits should be communicated in the in-app defect resolution screen so users
have accurate expectations before they go through the process.

### 2.3 Escalation to Georgian civil law

For high-value disputes (estimated value > ₾500) where the seller refuses to cooperate
and a clear misrepresentation is documented:

- The buyer may pursue a claim under the **Law of Georgia on Consumer Protection**
  (კანონი „მომხმარებელთა უფლებების დაცვის შესახებ") or through the
  **National Agency for Competition and Consumer Affairs (NACC)** — hotline: **1505**.
- Kosmeo can provide a read-only export of the relevant chat log and listing data
  to the buyer upon written request to `hello@kosmeo.ge`.

---

## 3. Automated Chat Warning Triggers

### 3.1 How the system works

The keyword scanner runs **client-side only**, on every `onChange` event in the Chat
text input. It does not log anything to the server — it is purely a real-time
educational nudge. When a trigger is matched, an amber dismissible banner
appears above the input bar.

The scanner is deliberately broad (partial word matching, both English and Georgian)
to catch evasion attempts like "whatsap" or "გადა...".

### 3.2 Trigger rules

| Rule name | Example trigger words | Warning displayed |
|---|---|---|
| `chatWarn_transfer` | transfer, bank, ბანკ, card, ბარათ, crypto, გადარიცხ | Cash-only reminder, never transfer before receiving item |
| `chatWarn_shipping` | ship, shipped, courier, კურიერ, post, ფოსტ, delivery, მიტანა | No shipping on Kosmeo; face-to-face only |
| `chatWarn_offplatform` | telegram, whatsapp, viber, instagram, dm me, პირადად | Keep negotiations in-app for safety record |
| `chatWarn_deposit` | deposit, დეპოზიტ, advance, წინასწარ | Never pay a deposit before meeting |

### 3.3 Dismissal behaviour

- The user can dismiss a banner with the ✕ button.
- Once dismissed, that **specific warning key** will not re-appear in the same chat session
  (tracked in a `dismissedWarns` Set in component state).
- If the user types a different trigger word, the banner for the new category will appear.
- Warnings do **not** block message sending. They are informational, not gatekeeping.

### 3.4 Extending the trigger list

Add new rules to the `KEYWORD_RULES` array in `Chat.jsx`:

```js
{
  patterns: /your_regex_here/i,
  warnKey: "chatWarn_yourKey",   // add matching string to both locale files
}
```

The moderation team should review and update this list quarterly based on
reported scam language patterns observed in the reports queue.

### 3.5 Future: server-side flagging

When the platform scales, consider adding a server-side pass on `POST /api/messages/conversations/:id`:

```js
const MONITORED_PATTERNS = [/transfer/i, /telegram/i, /deposit/i, /ship/i];
const flagged = MONITORED_PATTERNS.some(p => p.test(body));
if (flagged) {
  // Set messages.is_flagged = true in DB
  // Can be surfaced in admin queue as "suspicious conversation"
}
```

This would give moderators visibility into conversations that never resulted in a report
but contain suspicious language, without reading message content proactively.

---

## 4. Progressive Consequence Ladder

| Stage | Trigger | Action | Reversible? |
|---|---|---|---|
| **Advisory** | 1 confirmed minor violation | `warning_count + 1`; seller sees no in-app message (internal only) | Yes |
| **Formal warning** | 2 confirmed violations | `warning_count + 1`; email sent to user's registered address | Yes (appeal) |
| **Listing removal** | Confirmed fake/counterfeit listing | `is_active = false` on offending listing | Yes (appeal within 7 days) |
| **Account suspension** | 3 warnings or confirmed scam | All listings hidden; login blocked for 14 days | Yes (appeal) |
| **Permanent ban** | Sustained ban violation or serious harm | `is_banned = true`; email blacklisted | No |

**Note on banned users and login:** When `is_banned = true`, the server's `requireAuth`
middleware should check this flag and return a `403` with a specific error code that the
front-end can distinguish from a normal auth error — e.g., show a "Your account has been
suspended" screen rather than redirecting to `/login`.

---

## 5. Data Retention & Privacy

- **Reports:** Retained for 2 years from creation date, then anonymised (reporter_id and reported_user_id set to NULL, reason and detail preserved for trend analysis).
- **Flagged conversations:** Full chat log retained for 6 months from the date a report is filed against that conversation.
- **User data on ban:** Username and email retained (to prevent re-registration); all other profile data deleted after 30 days.
- **Exports to users:** Users may request their own data (chat logs, listings, reviews) by emailing `hello@kosmeo.ge`. Provide within 14 days.

---

## 6. Roles & Responsibilities (current)

| Role | Responsibilities |
|---|---|
| **Founder / Admin** | Full moderator access; appeal decisions; policy updates |
| **Community Moderator** (future hire) | Daily queue review; tier-1 report resolution; escalates bans to founder |
| **Users** | First line of defence; flag issues; leave accurate reviews |

---

*Last updated: June 2026. Review quarterly or after any significant change to the transaction model.*
