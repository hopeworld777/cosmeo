/**
 * Add this `reports` block to the existing `api` object in src/lib/api.js
 *
 * Example — your current api.js likely exports something like:
 *   export const api = { listings: { ... }, messages: { ... }, ... }
 *
 * Add:
 *   reports: { ... }
 *
 * Full snippet to paste into the api object:
 */

reports: {
  /**
   * Submit a new report from the chat or listing page.
   * @param {Object} payload
   * @param {number|null} payload.reported_user_id
   * @param {number|null} payload.listing_id
   * @param {number|null} payload.conversation_id
   * @param {string}      payload.reason        - one of the VALID_REASONS enum values
   * @param {string}      payload.detail        - optional free-text, max 500 chars
   */
  create: async ({ reported_user_id, listing_id, conversation_id, reason, detail }) => {
    const res = await fetch("/api/reports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ reported_user_id, listing_id, conversation_id, reason, detail }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || "Failed to submit report");
    }
    return res.json();
  },
},
