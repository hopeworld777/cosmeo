/**
 * server/routes/reports.js
 *
 * Handles user & listing reports for Kosmeo's moderation queue.
 *
 * Register in server/index.js:
 *   import reportsRouter from "./routes/reports.js";
 *   app.use("/api/reports", reportsRouter);
 *
 * Required DB migration (run once):
 *   CREATE TYPE report_reason AS ENUM (
 *     'report_reason_scam',
 *     'report_reason_fake_listing',
 *     'report_reason_offplatform',
 *     'report_reason_harassment',
 *     'report_reason_counterfeit',
 *     'report_reason_other'
 *   );
 *
 *   CREATE TABLE reports (
 *     id               SERIAL PRIMARY KEY,
 *     reporter_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 *     reported_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 *     listing_id       INTEGER REFERENCES listings(id) ON DELETE SET NULL,
 *     conversation_id  INTEGER REFERENCES conversations(id) ON DELETE SET NULL,
 *     reason           TEXT    NOT NULL,
 *     detail           TEXT,
 *     status           TEXT    NOT NULL DEFAULT 'open',   -- open | reviewed | resolved | dismissed
 *     created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 *     reviewed_at      TIMESTAMPTZ,
 *     reviewed_by      INTEGER REFERENCES users(id) ON DELETE SET NULL,
 *     resolution_note  TEXT
 *   );
 *
 *   CREATE INDEX reports_status_idx ON reports(status);
 *   CREATE INDEX reports_reporter_idx ON reports(reporter_id);
 *   CREATE INDEX reports_reported_user_idx ON reports(reported_user_id);
 *
 *   -- Auto-flag listings that accumulate ≥ 3 open reports
 *   CREATE OR REPLACE FUNCTION flag_listing_on_report()
 *   RETURNS TRIGGER LANGUAGE plpgsql AS $$
 *   BEGIN
 *     UPDATE listings
 *     SET is_flagged = true
 *     WHERE id = NEW.listing_id
 *       AND (SELECT COUNT(*) FROM reports WHERE listing_id = NEW.listing_id AND status = 'open') >= 3;
 *     RETURN NEW;
 *   END;
 *   $$;
 *
 *   CREATE TRIGGER after_report_insert
 *   AFTER INSERT ON reports
 *   FOR EACH ROW WHEN (NEW.listing_id IS NOT NULL)
 *   EXECUTE FUNCTION flag_listing_on_report();
 *
 *   -- Add is_flagged column to listings if not present:
 *   ALTER TABLE listings ADD COLUMN IF NOT EXISTS is_flagged BOOLEAN NOT NULL DEFAULT false;
 *
 *   -- Add is_banned column to users if not present:
 *   ALTER TABLE users ADD COLUMN IF NOT EXISTS is_banned BOOLEAN NOT NULL DEFAULT false;
 *   ALTER TABLE users ADD COLUMN IF NOT EXISTS warning_count INTEGER NOT NULL DEFAULT 0;
 */

import { Router } from "express";
import { z } from "zod";
import pool from "../db.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

const VALID_REASONS = [
  "report_reason_scam",
  "report_reason_fake_listing",
  "report_reason_offplatform",
  "report_reason_harassment",
  "report_reason_counterfeit",
  "report_reason_other",
];

const createReportSchema = z.object({
  reported_user_id: z.number().int().positive().nullable().optional(),
  listing_id:       z.number().int().positive().nullable().optional(),
  conversation_id:  z.number().int().positive().nullable().optional(),
  reason:           z.enum(VALID_REASONS),
  detail:           z.string().max(500).optional().default(""),
});

// ── POST /api/reports ─────────────────────────────────────────────────────────
// Submit a new report. Returns the created report row.
router.post("/", requireAuth, async (req, res) => {
  const parsed = createReportSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.issues[0]?.message || "Invalid payload" });
  }

  const { reported_user_id, listing_id, conversation_id, reason, detail } = parsed.data;

  // Must report something
  if (!reported_user_id && !listing_id) {
    return res.status(400).json({ error: "Must supply reported_user_id or listing_id" });
  }

  // Prevent self-report
  if (reported_user_id && reported_user_id === req.userId) {
    return res.status(400).json({ error: "Cannot report yourself" });
  }

  // Prevent duplicate open reports from same reporter for same target
  const dupe = await pool.query(
    `SELECT id FROM reports
     WHERE reporter_id = $1
       AND (reported_user_id = $2 OR listing_id = $3)
       AND status = 'open'
     LIMIT 1`,
    [req.userId, reported_user_id ?? null, listing_id ?? null]
  );
  if (dupe.rows[0]) {
    return res.status(409).json({ error: "You already have an open report for this target" });
  }

  try {
    const result = await pool.query(
      `INSERT INTO reports
         (reporter_id, reported_user_id, listing_id, conversation_id, reason, detail)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, status, created_at`,
      [req.userId, reported_user_id ?? null, listing_id ?? null, conversation_id ?? null, reason, detail]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("Create report error:", err);
    res.status(500).json({ error: "Failed to submit report" });
  }
});

// ── GET /api/reports/admin ────────────────────────────────────────────────────
// Internal admin queue. Protect with an is_admin guard in production.
// For now, restrict to users with admin flag (add is_admin column to users).
router.get("/admin", requireAuth, async (req, res) => {
  // Simple admin check — replace with proper role middleware when ready
  const adminCheck = await pool.query("SELECT is_admin FROM users WHERE id = $1", [req.userId]);
  if (!adminCheck.rows[0]?.is_admin) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const { status = "open", limit = 50, offset = 0 } = req.query;

  try {
    const result = await pool.query(
      `SELECT r.*,
              reporter.username  AS reporter_username,
              reported.username  AS reported_username,
              l.title            AS listing_title
       FROM reports r
       LEFT JOIN users reporter ON reporter.id = r.reporter_id
       LEFT JOIN users reported ON reported.id = r.reported_user_id
       LEFT JOIN listings l     ON l.id        = r.listing_id
       WHERE ($1::text = 'all' OR r.status = $1)
       ORDER BY r.created_at DESC
       LIMIT $2 OFFSET $3`,
      [status, parseInt(limit), parseInt(offset)]
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Admin reports error:", err);
    res.status(500).json({ error: "Failed to fetch reports" });
  }
});

// ── PATCH /api/reports/admin/:id ──────────────────────────────────────────────
// Resolve or dismiss a report. Optionally apply action to the reported user.
router.patch("/admin/:id", requireAuth, async (req, res) => {
  const adminCheck = await pool.query("SELECT is_admin FROM users WHERE id = $1", [req.userId]);
  if (!adminCheck.rows[0]?.is_admin) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const { status, resolution_note, action } = req.body;
  // action: null | "warn_user" | "ban_user" | "remove_listing"
  const VALID_STATUSES = ["reviewed", "resolved", "dismissed"];
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const report = await client.query(
      "SELECT * FROM reports WHERE id = $1", [req.params.id]
    );
    if (!report.rows[0]) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Report not found" });
    }

    const r = report.rows[0];

    // Update report status
    await client.query(
      `UPDATE reports SET status=$1, resolution_note=$2, reviewed_at=NOW(), reviewed_by=$3
       WHERE id=$4`,
      [status, resolution_note || null, req.userId, req.params.id]
    );

    // Apply optional moderation action
    if (action === "warn_user" && r.reported_user_id) {
      await client.query(
        "UPDATE users SET warning_count = warning_count + 1 WHERE id = $1",
        [r.reported_user_id]
      );
    } else if (action === "ban_user" && r.reported_user_id) {
      await client.query(
        "UPDATE users SET is_banned = true WHERE id = $1",
        [r.reported_user_id]
      );
    } else if (action === "remove_listing" && r.listing_id) {
      await client.query(
        "UPDATE listings SET is_active = false, is_flagged = true WHERE id = $1",
        [r.listing_id]
      );
    }

    await client.query("COMMIT");
    res.json({ success: true, action: action || null });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Admin resolve report error:", err);
    res.status(500).json({ error: "Failed to update report" });
  } finally {
    client.release();
  }
});

export default router;
