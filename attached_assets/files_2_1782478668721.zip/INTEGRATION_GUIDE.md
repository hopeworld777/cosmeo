# Kosmeo — Terms & Safety Page: Integration Guide

## Files delivered

| File | Purpose |
|------|---------|
| `TermsAndSafety.jsx` | React page component — drop into `src/pages/` |
| `en_tos_keys.json` | English i18n keys — merge into `src/locales/en/translation.json` |
| `ka_tos_keys.json` | Georgian i18n keys — merge into `src/locales/ka/translation.json` |

---

## Step 1 — Copy the component

```bash
cp TermsAndSafety.jsx src/pages/TermsAndSafety.jsx
```

---

## Step 2 — Merge translation keys

Open `src/locales/en/translation.json` and paste every key from `en_tos_keys.json`
(all keys beginning with `tos_`) into the root JSON object.

Do the same for `src/locales/ka/translation.json` using `ka_tos_keys.json`.

> Tip: Don't copy the `_comment` key — it's for your reference only.

---

## Step 3 — Register the route in App.jsx

Add one import and one Route:

```jsx
// At the top with other imports:
import TermsAndSafety from "@/pages/TermsAndSafety";

// Inside the <Switch> block (no auth guard needed — page is public):
<Route path="/terms" component={TermsAndSafety} />
```

---

## Step 4 — Link from the Register page (and anywhere else)

In `src/pages/Register.jsx`, find the `termsNotice` text and wrap "Terms of Service"
with a navigation link:

```jsx
import { Link } from "wouter";

// In your JSX:
<p className="text-xs text-muted-foreground text-center mt-2">
  {t("termsNoticePrefix")}{" "}
  <Link href="/terms" className="underline text-primary font-semibold">
    {t("termsNoticeLinkText")}
  </Link>
  .
</p>
```

Add those two small keys to both locale files:
```json
"termsNoticePrefix": "By creating an account you agree to our",
"termsNoticeLinkText": "Terms of Service & Safety Guidelines"
```

Georgian:
```json
"termsNoticePrefix": "ანგარიშის შექმნით ეთანხმებით ჩვენს",
"termsNoticeLinkText": "მომსახურების პირობებს და უსაფრთხოების გაიდლაინებს"
```

---

## Step 5 — Link from the Settings page (optional but recommended)

In `src/pages/Settings.jsx`, add a footer row below the Save button:

```jsx
import { Link } from "wouter";

<Link href="/terms" className="text-xs text-muted-foreground underline mt-4 block text-center">
  {t("tos_pageTitle")}
</Link>
```

---

## Step 6 — Add to BottomNav overflow menu (optional)

If you add a "More" or account menu in `BottomNav.jsx`, include:

```jsx
{ label: t("tos_pageTitle"), path: "/terms", icon: ShieldCheck }
```

---

## Dependency check

The component uses:
- `framer-motion` ✅ already in your project
- `react-i18next` ✅ already in your project
- `lucide-react` ✅ already in your project
- `wouter` ✅ already in your project
- Tailwind CSS custom tokens from `index.css` ✅ all referenced classes exist

No new packages are needed.

---

## What the page does

**Safety Guide tab** (default open):
- Collapsible accordions: Before You Meet · At the Meetup · Red Flags
- Quick-tip pills with emoji anchors
- City-specific meetup hub grid (all 7 Kosmeo cities)
- Trust tier explainer callout

**Terms of Service tab**:
- 10 sections covering eligibility, listings, prohibited conduct,
  liability, reviews/tiers, IP, privacy, governing law
- Effective date + Georgian jurisdiction clearly stated
- Contact email footer

Both tabs are fully translated into Georgian and respect the existing
`i18next` language toggle — switching language while on the page
updates all text instantly.
